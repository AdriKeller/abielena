import game

game.Game()
